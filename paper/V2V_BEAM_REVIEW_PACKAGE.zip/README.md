# V2V beam forecasting review package

Open paper/V2V_BEAM_FORECASTING_MANUSCRIPT.html in a browser after extracting the whole folder. The Markdown source and both figures are included. The archive contains derived validation summaries. It can be reviewed offline.

## Reproduce the full-codebook comparison

Use Python 3 with NumPy installed, then run the following from this folder.

    python results/swin_comparison_v1/stage299/reproduce.py

The script verifies all 20 reported point estimates and paired block intervals against contrasts.json and prints the exploratory alternative-beam success contrast. Each CSV row aggregates one recording block, split, arm and seed. Columns hit, success and alternative are event counts; regret and top1_loss_db are summed losses in dB; n is the window count. Repeated geometry rows support matched comparisons across seeds. The bootstrap keeps all arms paired within a resampled block. The 11 blocks cover four previously explored scenarios.

The source exporter documents how block totals were obtained from the project predictions. Regenerating those totals or retraining requires the full project and input data. The included shortlist and earlier split analyses are archived summaries. SHA256SUMS.txt lists the package files and their SHA-256 digests.
